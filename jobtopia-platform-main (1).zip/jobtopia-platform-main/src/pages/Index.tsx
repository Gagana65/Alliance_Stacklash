
import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import Navbar from '@/components/Navbar';
import SearchBar from '@/components/SearchBar';
import AnimatedRoute from '@/components/AnimatedRoute';
import { ArrowRight, Briefcase, Search, Check } from 'lucide-react';

const Index: React.FC = () => {
  const handleSearch = (query: string, location: string) => {
    // In a real app, we'd use this to navigate with search params
    window.location.href = `/jobs?q=${query}&location=${location}`;
  };

  return (
    <>
      <Navbar />
      <AnimatedRoute>
        <main className="flex flex-col min-h-screen pt-20">
          {/* Hero Section */}
          <section className="page-section pt-16 md:pt-24">
            <div className="page-container">
              <div className="flex flex-col items-center text-center">
                <motion.div
                  className="mb-3 bg-primary/10 text-primary px-4 py-1.5 rounded-full text-sm font-medium"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, ease: [0.25, 0.1, 0.25, 1] }}
                >
                  Find your dream job today
                </motion.div>
                
                <motion.h1 
                  className="text-4xl md:text-6xl font-display font-bold tracking-tight text-balance mb-4"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.1, ease: [0.25, 0.1, 0.25, 1] }}
                >
                  Your career journey 
                  <span className="bg-clip-text text-transparent bg-gradient-to-r from-primary to-primary/70">
                    {" "}starts here
                  </span>
                </motion.h1>
                
                <motion.p 
                  className="text-xl text-muted-foreground max-w-2xl text-balance mb-10"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.2, ease: [0.25, 0.1, 0.25, 1] }}
                >
                  Connect with leading companies and discover opportunities that match your skills and ambitions.
                </motion.p>
                
                <motion.div 
                  className="w-full"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.3, ease: [0.25, 0.1, 0.25, 1] }}
                >
                  <SearchBar onSearch={handleSearch} />
                </motion.div>
                
                <motion.div 
                  className="mt-8 flex flex-wrap justify-center gap-3 text-sm text-muted-foreground"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.5, delay: 0.4 }}
                >
                  <span>Popular searches:</span>
                  <Link to="/jobs?q=software%20engineer" className="hover:text-primary hover:underline transition-colors">Software Engineer</Link>
                  <Link to="/jobs?q=product%20manager" className="hover:text-primary hover:underline transition-colors">Product Manager</Link>
                  <Link to="/jobs?q=data%20scientist" className="hover:text-primary hover:underline transition-colors">Data Scientist</Link>
                  <Link to="/jobs?q=remote" className="hover:text-primary hover:underline transition-colors">Remote Jobs</Link>
                </motion.div>
              </div>
            </div>
          </section>
          
          {/* Features Section */}
          <section className="page-section bg-secondary/50 mt-16 py-20">
            <div className="page-container">
              <div className="text-center mb-16">
                <motion.h2 
                  className="text-3xl md:text-4xl font-display font-bold"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, ease: [0.25, 0.1, 0.25, 1] }}
                  viewport={{ once: true }}
                >
                  Why use JobTopia?
                </motion.h2>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <FeatureCard 
                  icon={<Search className="h-6 w-6" />}
                  title="Smart Job Matching"
                  description="Our intelligent algorithm matches your skills and preferences with the perfect job opportunities."
                  index={0}
                />
                <FeatureCard 
                  icon={<Briefcase className="h-6 w-6" />}
                  title="Premium Employers"
                  description="Connect with top companies across various industries looking for talent like you."
                  index={1}
                />
                <FeatureCard 
                  icon={<Check className="h-6 w-6" />}
                  title="Streamlined Applications"
                  description="Apply to multiple positions with just a few clicks and track your application status."
                  index={2}
                />
              </div>
              
              <div className="mt-16 text-center">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.6, ease: [0.25, 0.1, 0.25, 1] }}
                  viewport={{ once: true }}
                >
                  <Button asChild size="lg" className="rounded-full button-press">
                    <Link to="/jobs" className="flex items-center">
                      Browse all jobs <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </motion.div>
              </div>
            </div>
          </section>
          
          {/* Footer */}
          <footer className="mt-auto bg-muted/30 py-10">
            <div className="page-container">
              <div className="flex flex-col md:flex-row justify-between items-center">
                <div className="mb-4 md:mb-0">
                  <p className="text-sm text-muted-foreground">
                    © 2023 JobTopia. All rights reserved.
                  </p>
                </div>
                <div className="flex space-x-6">
                  <Link to="/terms" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Terms</Link>
                  <Link to="/privacy" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Privacy</Link>
                  <Link to="/contact" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Contact</Link>
                </div>
              </div>
            </div>
          </footer>
        </main>
      </AnimatedRoute>
    </>
  );
};

interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  index: number;
}

const FeatureCard: React.FC<FeatureCardProps> = ({ icon, title, description, index }) => {
  return (
    <motion.div 
      className="glass-card rounded-2xl p-6 hover-scale"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ 
        duration: 0.5, 
        delay: 0.3 + (index * 0.15), 
        ease: [0.25, 0.1, 0.25, 1] 
      }}
      viewport={{ once: true }}
    >
      <div className="h-12 w-12 rounded-full bg-primary/10 text-primary flex items-center justify-center mb-4">
        {icon}
      </div>
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-muted-foreground">{description}</p>
    </motion.div>
  );
};

export default Index;
