
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import Navbar from '@/components/Navbar';
import AnimatedRoute from '@/components/AnimatedRoute';
import { User, FileText, Save } from 'lucide-react';

interface UserProfile {
  name: string;
  email: string;
  phone: string;
  bio: string;
  resumeFile: File | null;
  skills: string[];
}

const Profile: React.FC = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const userLoggedIn = localStorage.getItem('userLoggedIn') === 'true';
  const userData = userLoggedIn 
    ? JSON.parse(localStorage.getItem('userData') || '{}') 
    : null;
  
  const [profile, setProfile] = useState<UserProfile>({
    name: userData?.name || '',
    email: userData?.email || '',
    phone: '',
    bio: '',
    resumeFile: null,
    skills: [],
  });
  
  const [skillInput, setSkillInput] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  
  // Redirect if not logged in
  useEffect(() => {
    if (!userLoggedIn) {
      navigate('/auth?mode=login');
    }
  }, [userLoggedIn, navigate]);
  
  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setProfile(prev => ({ ...prev, [name]: value }));
  };
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setProfile(prev => ({ ...prev, resumeFile: e.target.files?.[0] || null }));
    }
  };
  
  const handleAddSkill = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && skillInput.trim()) {
      e.preventDefault();
      if (!profile.skills.includes(skillInput.trim())) {
        setProfile(prev => ({
          ...prev,
          skills: [...prev.skills, skillInput.trim()],
        }));
      }
      setSkillInput('');
    }
  };
  
  const handleRemoveSkill = (skillToRemove: string) => {
    setProfile(prev => ({
      ...prev,
      skills: prev.skills.filter(skill => skill !== skillToRemove),
    }));
  };
  
  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    
    // Simulate API call
    setTimeout(() => {
      // Update stored user data
      const updatedUserData = {
        ...userData,
        name: profile.name,
        email: profile.email,
      };
      
      localStorage.setItem('userData', JSON.stringify(updatedUserData));
      
      toast({
        title: "Profile updated",
        description: "Your profile has been successfully updated.",
      });
      
      setIsSaving(false);
    }, 1500);
  };
  
  return (
    <>
      <Navbar />
      <AnimatedRoute>
        <main className="min-h-screen pt-20">
          <div className="page-container py-8">
            <h1 className="text-3xl font-display font-bold mb-8 text-center">Your Profile</h1>
            
            <motion.div 
              className="glass-card rounded-2xl p-8 max-w-2xl mx-auto"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, ease: [0.25, 0.1, 0.25, 1] }}
            >
              <div className="flex items-center justify-center mb-8">
                <div className="h-20 w-20 rounded-full bg-primary/10 flex items-center justify-center">
                  <User className="h-10 w-10 text-primary/60" />
                </div>
              </div>
              
              <form onSubmit={handleSaveProfile} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="name">Full Name</Label>
                  <Input
                    id="name"
                    name="name"
                    value={profile.name}
                    onChange={handleInputChange}
                    className="glass-input"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    value={profile.email}
                    onChange={handleInputChange}
                    className="glass-input"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input
                    id="phone"
                    name="phone"
                    value={profile.phone}
                    onChange={handleInputChange}
                    className="glass-input"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="bio">Professional Bio</Label>
                  <Textarea
                    id="bio"
                    name="bio"
                    placeholder="Tell employers a bit about yourself..."
                    value={profile.bio}
                    onChange={handleInputChange}
                    className="glass-input min-h-[150px]"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="skills">Skills</Label>
                  <Input
                    id="skills"
                    value={skillInput}
                    onChange={(e) => setSkillInput(e.target.value)}
                    onKeyDown={handleAddSkill}
                    placeholder="Type a skill and press Enter"
                    className="glass-input"
                  />
                  
                  {profile.skills.length > 0 && (
                    <div className="flex flex-wrap gap-2 mt-3">
                      {profile.skills.map((skill, index) => (
                        <div
                          key={index}
                          className="bg-primary/10 text-primary px-3 py-1 rounded-full text-sm flex items-center"
                        >
                          {skill}
                          <button
                            type="button"
                            onClick={() => handleRemoveSkill(skill)}
                            className="ml-2 h-4 w-4 rounded-full flex items-center justify-center hover:bg-primary/20 transition-colors"
                          >
                            ×
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="resume">Resume</Label>
                  <div className="flex items-center gap-4">
                    <Button
                      type="button"
                      variant="outline"
                      className="button-press"
                      onClick={() => document.getElementById('resume')?.click()}
                    >
                      <FileText className="mr-2 h-4 w-4" />
                      {profile.resumeFile ? 'Change resume' : 'Upload resume'}
                    </Button>
                    {profile.resumeFile && (
                      <span className="text-sm text-muted-foreground">
                        {profile.resumeFile.name}
                      </span>
                    )}
                  </div>
                  <input
                    id="resume"
                    name="resume"
                    type="file"
                    accept=".pdf,.doc,.docx"
                    onChange={handleFileChange}
                    className="hidden"
                  />
                  <p className="text-xs text-muted-foreground mt-2">
                    Accepted formats: PDF, DOC, DOCX
                  </p>
                </div>
                
                <div className="pt-4">
                  <Button
                    type="submit"
                    className="w-full button-press"
                    disabled={isSaving}
                  >
                    <Save className="mr-2 h-4 w-4" />
                    {isSaving ? 'Saving...' : 'Save Profile'}
                  </Button>
                </div>
              </form>
            </motion.div>
          </div>
        </main>
      </AnimatedRoute>
    </>
  );
};

export default Profile;
