
import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import Navbar from '@/components/Navbar';
import SearchBar from '@/components/SearchBar';
import JobCard, { JobData } from '@/components/JobCard';
import AnimatedRoute from '@/components/AnimatedRoute';
import { Check } from 'lucide-react';

// Mock job data
const mockJobs: JobData[] = [
  {
    id: '1',
    title: 'Frontend Developer',
    company: 'TechCorp',
    location: 'San Francisco, CA',
    salary: '$120,000 - $140,000',
    type: 'Full-time',
    posted: '2 days ago',
    logo: 'https://picsum.photos/seed/tech1/200',
    description: 'We are looking for a skilled Frontend Developer to join our team. You will be responsible for building user interfaces and implementing design systems.'
  },
  {
    id: '2',
    title: 'Product Manager',
    company: 'InnovateCo',
    location: 'Remote',
    salary: '$130,000 - $150,000',
    type: 'Full-time',
    posted: '5 days ago',
    logo: 'https://picsum.photos/seed/inn2/200',
    description: 'As a Product Manager, you will lead the development of our flagship product from conception to launch, working closely with engineering, design, and marketing teams.'
  },
  {
    id: '3',
    title: 'Data Scientist',
    company: 'AnalyticsPro',
    location: 'Boston, MA',
    salary: '$115,000 - $135,000',
    type: 'Full-time',
    posted: '1 week ago',
    logo: 'https://picsum.photos/seed/ana3/200',
    description: 'Join our data science team to analyze complex datasets and develop machine learning models to solve business problems.'
  },
  {
    id: '4',
    title: 'UX Designer',
    company: 'DesignHub',
    location: 'New York, NY',
    salary: '$100,000 - $120,000',
    type: 'Full-time',
    posted: '3 days ago',
    logo: 'https://picsum.photos/seed/des4/200',
    description: 'We are seeking a talented UX Designer to create intuitive and engaging user experiences for our digital products.'
  },
  {
    id: '5',
    title: 'Backend Engineer',
    company: 'ServerStack',
    location: 'Remote',
    salary: '$125,000 - $145,000',
    type: 'Full-time',
    posted: '1 day ago',
    logo: 'https://picsum.photos/seed/ser5/200',
    description: 'Design and implement scalable backend systems and APIs to power our growing platform.'
  },
  {
    id: '6',
    title: 'Marketing Specialist',
    company: 'GrowthGenius',
    location: 'Chicago, IL',
    salary: '$80,000 - $95,000',
    type: 'Full-time',
    posted: '1 week ago',
    logo: 'https://picsum.photos/seed/gro6/200',
    description: 'Drive our marketing efforts through various channels including social media, email, and content marketing.'
  },
  {
    id: '7',
    title: 'DevOps Engineer',
    company: 'CloudNative',
    location: 'Austin, TX',
    salary: '$130,000 - $150,000',
    type: 'Full-time',
    posted: '4 days ago',
    logo: 'https://picsum.photos/seed/clo7/200',
    description: 'Build and maintain our CI/CD pipelines, infrastructure, and deployment processes.'
  },
  {
    id: '8',
    title: 'Content Writer',
    company: 'ContentKing',
    location: 'Remote',
    salary: '$70,000 - $85,000',
    type: 'Part-time',
    posted: '3 days ago',
    logo: 'https://picsum.photos/seed/con8/200',
    description: 'Create engaging, high-quality content for our blog, website, and marketing materials.'
  },
];

const Jobs: React.FC = () => {
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const initialQuery = queryParams.get('q') || '';
  const initialLocation = queryParams.get('location') || '';
  
  const [query, setQuery] = useState(initialQuery);
  const [locationFilter, setLocationFilter] = useState(initialLocation);
  const [filteredJobs, setFilteredJobs] = useState<JobData[]>(mockJobs);
  const [isLoading, setIsLoading] = useState(true);
  
  useEffect(() => {
    // Simulate loading data
    setIsLoading(true);
    
    setTimeout(() => {
      // In a real app, this would be an API call
      if (query || locationFilter) {
        const lowercaseQuery = query.toLowerCase();
        const lowercaseLocation = locationFilter.toLowerCase();
        
        const filtered = mockJobs.filter(job => {
          const matchesQuery = !query || 
            job.title.toLowerCase().includes(lowercaseQuery) || 
            job.company.toLowerCase().includes(lowercaseQuery) ||
            job.description.toLowerCase().includes(lowercaseQuery);
          
          const matchesLocation = !locationFilter || 
            job.location.toLowerCase().includes(lowercaseLocation);
          
          return matchesQuery && matchesLocation;
        });
        
        setFilteredJobs(filtered);
      } else {
        setFilteredJobs(mockJobs);
      }
      
      setIsLoading(false);
    }, 800);
  }, [query, locationFilter]);
  
  const handleSearch = (newQuery: string, newLocation: string) => {
    setQuery(newQuery);
    setLocationFilter(newLocation);
    
    // Update URL
    const params = new URLSearchParams();
    if (newQuery) params.set('q', newQuery);
    if (newLocation) params.set('location', newLocation);
    window.history.pushState({}, '', `${location.pathname}?${params.toString()}`);
  };
  
  return (
    <>
      <Navbar />
      <AnimatedRoute>
        <main className="min-h-screen pt-20">
          <section className="page-section pt-8">
            <div className="page-container">
              <h1 className="text-3xl font-display font-bold mb-8 text-center">Find Your Next Opportunity</h1>
              <SearchBar onSearch={handleSearch} />
              
              <div className="mt-10">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-xl font-semibold">
                    {isLoading ? 'Searching for jobs...' : (
                      filteredJobs.length > 0 
                        ? `Found ${filteredJobs.length} jobs` 
                        : 'No jobs found'
                    )}
                  </h2>
                  
                  {(query || locationFilter) && (
                    <div className="text-sm text-muted-foreground">
                      <span>Filters:</span>
                      {query && (
                        <span className="ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary/10 text-primary">
                          <Check className="mr-1 h-3 w-3" /> {query}
                        </span>
                      )}
                      {locationFilter && (
                        <span className="ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary/10 text-primary">
                          <Check className="mr-1 h-3 w-3" /> {locationFilter}
                        </span>
                      )}
                    </div>
                  )}
                </div>
                
                {isLoading ? (
                  <div className="space-y-4">
                    {[1, 2, 3, 4].map((_, i) => (
                      <div key={i} className="w-full h-32 bg-muted/30 rounded-2xl animate-pulse" />
                    ))}
                  </div>
                ) : (
                  <div className="space-y-4">
                    {filteredJobs.length > 0 ? (
                      filteredJobs.map((job, index) => (
                        <JobCard key={job.id} job={job} index={index} />
                      ))
                    ) : (
                      <div className="text-center py-12">
                        <p className="text-lg text-muted-foreground">
                          No jobs match your search criteria. Try adjusting your filters.
                        </p>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          </section>
        </main>
      </AnimatedRoute>
    </>
  );
};

export default Jobs;
