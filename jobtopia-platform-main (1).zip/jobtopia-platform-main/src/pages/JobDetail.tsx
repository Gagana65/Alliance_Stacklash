
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import Navbar from '@/components/Navbar';
import AnimatedRoute from '@/components/AnimatedRoute';
import { Calendar, Briefcase, ArrowLeft, FileText } from 'lucide-react';
import { JobData } from '@/components/JobCard';

// Mock job data
const mockJobs: JobData[] = [
  {
    id: '1',
    title: 'Frontend Developer',
    company: 'TechCorp',
    location: 'San Francisco, CA',
    salary: '$120,000 - $140,000',
    type: 'Full-time',
    posted: '2 days ago',
    logo: 'https://picsum.photos/seed/tech1/200',
    description: 'We are looking for a skilled Frontend Developer to join our team. You will be responsible for building user interfaces and implementing design systems. The ideal candidate has experience with React, TypeScript, and modern CSS practices.\n\nResponsibilities:\n• Develop high-quality user interfaces using React and TypeScript\n• Collaborate with designers to implement UI designs with pixel-perfect accuracy\n• Write clean, maintainable, and well-documented code\n• Optimize applications for maximum speed and scalability\n• Stay up-to-date with emerging trends and best practices in frontend development\n\nRequirements:\n• 3+ years of experience in frontend development\n• Strong proficiency in JavaScript, React, and TypeScript\n• Experience with responsive design and CSS frameworks\n• Knowledge of performance optimization techniques\n• Excellent problem-solving and communication skills'
  },
  {
    id: '2',
    title: 'Product Manager',
    company: 'InnovateCo',
    location: 'Remote',
    salary: '$130,000 - $150,000',
    type: 'Full-time',
    posted: '5 days ago',
    logo: 'https://picsum.photos/seed/inn2/200',
    description: 'As a Product Manager, you will lead the development of our flagship product from conception to launch, working closely with engineering, design, and marketing teams. You will be responsible for defining product vision, strategy, and roadmap.\n\nResponsibilities:\n• Define product vision, strategy, and roadmap based on market research and user feedback\n• Collaborate with engineering, design, and marketing teams to deliver outstanding products\n• Gather and analyze user feedback to inform product decisions\n• Create detailed product specifications and acceptance criteria\n• Monitor product performance and identify opportunities for improvement\n\nRequirements:\n• 4+ years of experience in product management\n• Strong analytical and problem-solving skills\n• Excellent communication and collaboration abilities\n• Experience with agile methodologies\n• Technical background or understanding of software development principles'
  },
  {
    id: '3',
    title: 'Data Scientist',
    company: 'AnalyticsPro',
    location: 'Boston, MA',
    salary: '$115,000 - $135,000',
    type: 'Full-time',
    posted: '1 week ago',
    logo: 'https://picsum.photos/seed/ana3/200',
    description: 'Join our data science team to analyze complex datasets and develop machine learning models to solve business problems. You will work with large datasets to extract insights and build predictive models.\n\nResponsibilities:\n• Analyze large datasets to extract insights and identify patterns\n• Develop machine learning models to solve business problems\n• Collaborate with engineering teams to implement data science solutions\n• Communicate findings to stakeholders in a clear and compelling manner\n• Stay up-to-date with latest advancements in data science and machine learning\n\nRequirements:\n• Master\'s or PhD in Computer Science, Statistics, or related field\n• 3+ years of experience in data science or machine learning\n• Strong programming skills in Python and R\n• Experience with ML frameworks such as TensorFlow or PyTorch\n• Excellent analytical and problem-solving abilities'
  },
  {
    id: '4',
    title: 'UX Designer',
    company: 'DesignHub',
    location: 'New York, NY',
    salary: '$100,000 - $120,000',
    type: 'Full-time',
    posted: '3 days ago',
    logo: 'https://picsum.photos/seed/des4/200',
    description: 'We are seeking a talented UX Designer to create intuitive and engaging user experiences for our digital products. You will work closely with product managers, developers, and other designers to create user-centered designs.\n\nResponsibilities:\n• Conduct user research and usability testing to inform design decisions\n• Create wireframes, prototypes, and high-fidelity mockups\n• Develop user flows, personas, and journey maps\n• Collaborate with developers to ensure proper implementation of designs\n• Continuously iterate on designs based on user feedback\n\nRequirements:\n• 3+ years of experience in UX design\n• Strong portfolio demonstrating your design process and skills\n• Proficiency with design tools such as Figma, Sketch, or Adobe XD\n• Knowledge of usability principles and best practices\n• Excellent communication and collaboration skills'
  },
  {
    id: '5',
    title: 'Backend Engineer',
    company: 'ServerStack',
    location: 'Remote',
    salary: '$125,000 - $145,000',
    type: 'Full-time',
    posted: '1 day ago',
    logo: 'https://picsum.photos/seed/ser5/200',
    description: 'Design and implement scalable backend systems and APIs to power our growing platform. You will work with various technologies to build robust and efficient server-side solutions.\n\nResponsibilities:\n• Design and develop scalable backend services and APIs\n• Implement database schemas and data models\n• Optimize systems for performance, reliability, and security\n• Participate in code reviews and mentor junior developers\n• Troubleshoot and resolve complex technical issues\n\nRequirements:\n• 4+ years of experience in backend development\n• Strong proficiency in languages such as Python, Node.js, or Go\n• Experience with databases (SQL and NoSQL)\n• Knowledge of cloud services (AWS, GCP, or Azure)\n• Understanding of microservices architecture'
  },
  {
    id: '6',
    title: 'Marketing Specialist',
    company: 'GrowthGenius',
    location: 'Chicago, IL',
    salary: '$80,000 - $95,000',
    type: 'Full-time',
    posted: '1 week ago',
    logo: 'https://picsum.photos/seed/gro6/200',
    description: 'Drive our marketing efforts through various channels including social media, email, and content marketing. You will be responsible for creating and implementing marketing campaigns to increase brand awareness and drive user acquisition.\n\nResponsibilities:\n• Develop and execute marketing campaigns across various channels\n• Create engaging content for social media, blog, and email newsletters\n• Monitor and analyze campaign performance using analytics tools\n• Manage relationships with marketing partners and vendors\n• Collaborate with design team to create marketing materials\n\nRequirements:\n• 2+ years of experience in digital marketing\n• Strong writing and communication skills\n• Experience with social media management and email marketing\n• Knowledge of SEO and content marketing principles\n• Analytical mindset with ability to derive insights from data'
  },
  {
    id: '7',
    title: 'DevOps Engineer',
    company: 'CloudNative',
    location: 'Austin, TX',
    salary: '$130,000 - $150,000',
    type: 'Full-time',
    posted: '4 days ago',
    logo: 'https://picsum.photos/seed/clo7/200',
    description: 'Build and maintain our CI/CD pipelines, infrastructure, and deployment processes. You will be responsible for ensuring the reliability, scalability, and security of our cloud infrastructure.\n\nResponsibilities:\n• Design and implement CI/CD pipelines for automated testing and deployment\n• Manage cloud infrastructure using infrastructure-as-code principles\n• Monitor system performance and resolve infrastructure issues\n• Implement security best practices and ensure compliance\n• Collaborate with development teams to improve deployment processes\n\nRequirements:\n• 3+ years of experience in DevOps or SRE roles\n• Strong knowledge of cloud platforms (AWS, GCP, or Azure)\n• Experience with containerization technologies (Docker, Kubernetes)\n• Proficiency with infrastructure-as-code tools (Terraform, CloudFormation)\n• Understanding of networking, security, and system architecture'
  },
  {
    id: '8',
    title: 'Content Writer',
    company: 'ContentKing',
    location: 'Remote',
    salary: '$70,000 - $85,000',
    type: 'Part-time',
    posted: '3 days ago',
    logo: 'https://picsum.photos/seed/con8/200',
    description: 'Create engaging, high-quality content for our blog, website, and marketing materials. You will be responsible for researching topics, writing articles, and ensuring content aligns with our brand voice and SEO strategy.\n\nResponsibilities:\n• Write clear, engaging, and SEO-optimized content for various platforms\n• Research industry trends and topics to create valuable content\n• Edit and proofread content to ensure quality and accuracy\n• Collaborate with marketing team to align content with campaign objectives\n• Optimize existing content based on performance data\n\nRequirements:\n• 2+ years of experience in content writing or journalism\n• Excellent writing and editing skills\n• Knowledge of SEO principles and content marketing\n• Ability to adapt writing style to different audiences\n• Strong research and organizational skills'
  },
];

const JobDetail: React.FC = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const [job, setJob] = useState<JobData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isApplying, setIsApplying] = useState(false);
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    coverLetter: '',
    resumeFile: null as File | null,
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Get user data if logged in
  const userLoggedIn = localStorage.getItem('userLoggedIn') === 'true';
  const userData = userLoggedIn ? JSON.parse(localStorage.getItem('userData') || '{}') : null;
  
  useEffect(() => {
    if (userData) {
      setFormData(prev => ({
        ...prev,
        fullName: userData.name || '',
        email: userData.email || '',
      }));
    }
  }, [userData]);
  
  useEffect(() => {
    setIsLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      const foundJob = mockJobs.find(j => j.id === id);
      setJob(foundJob || null);
      setIsLoading(false);
    }, 800);
  }, [id]);
  
  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setFormData(prev => ({ ...prev, resumeFile: e.target.files?.[0] || null }));
    }
  };
  
  const handleApply = () => {
    if (!userLoggedIn) {
      toast({
        title: "Authentication required",
        description: "Please log in or sign up to apply for this job.",
      });
      navigate('/auth?mode=login');
      return;
    }
    setIsApplying(true);
  };
  
  const handleSubmitApplication = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.fullName || !formData.email || !formData.resumeFile) {
      toast({
        title: "Missing information",
        description: "Please fill in all required fields and upload your resume.",
        variant: "destructive",
      });
      return;
    }
    
    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      toast({
        title: "Application submitted!",
        description: "Your application has been successfully submitted.",
      });
      
      setIsSubmitting(false);
      setIsApplying(false);
      
      // Redirect to jobs page after successful submission
      setTimeout(() => {
        navigate('/jobs');
      }, 1500);
    }, 2000);
  };
  
  if (isLoading) {
    return (
      <>
        <Navbar />
        <AnimatedRoute>
          <div className="min-h-screen pt-20">
            <div className="page-container py-8">
              <div className="w-full h-40 bg-muted/30 rounded-2xl animate-pulse mb-6" />
              <div className="w-full h-96 bg-muted/30 rounded-2xl animate-pulse" />
            </div>
          </div>
        </AnimatedRoute>
      </>
    );
  }
  
  if (!job) {
    return (
      <>
        <Navbar />
        <AnimatedRoute>
          <div className="min-h-screen pt-20">
            <div className="page-container py-12 text-center">
              <h1 className="text-2xl font-bold mb-4">Job Not Found</h1>
              <p className="text-muted-foreground mb-6">
                The job you're looking for doesn't exist or has been removed.
              </p>
              <Button asChild variant="outline">
                <Link to="/jobs" className="flex items-center">
                  <ArrowLeft className="mr-2 h-4 w-4" /> Back to Jobs
                </Link>
              </Button>
            </div>
          </div>
        </AnimatedRoute>
      </>
    );
  }
  
  return (
    <>
      <Navbar />
      <AnimatedRoute>
        <main className="min-h-screen pt-20">
          <div className="page-container py-8">
            <Button 
              asChild 
              variant="ghost" 
              size="sm"
              className="mb-6"
            >
              <Link to="/jobs" className="flex items-center">
                <ArrowLeft className="mr-2 h-4 w-4" /> Back to Jobs
              </Link>
            </Button>
            
            {isApplying ? (
              <div className="glass-card rounded-2xl p-8 max-w-2xl mx-auto">
                <h1 className="text-2xl font-bold mb-6">Apply for {job.title} at {job.company}</h1>
                
                <form onSubmit={handleSubmitApplication} className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="fullName">Full Name *</Label>
                    <Input
                      id="fullName"
                      name="fullName"
                      value={formData.fullName}
                      onChange={handleInputChange}
                      className="glass-input"
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="email">Email *</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      className="glass-input"
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input
                      id="phone"
                      name="phone"
                      value={formData.phone}
                      onChange={handleInputChange}
                      className="glass-input"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="coverLetter">Cover Letter</Label>
                    <Textarea
                      id="coverLetter"
                      name="coverLetter"
                      placeholder="Tell us why you're a great fit for this role..."
                      value={formData.coverLetter}
                      onChange={handleInputChange}
                      className="glass-input min-h-[150px]"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="resume">Resume *</Label>
                    <div className="flex items-center gap-4">
                      <Button
                        type="button"
                        variant="outline"
                        className="button-press"
                        onClick={() => document.getElementById('resume')?.click()}
                      >
                        <FileText className="mr-2 h-4 w-4" />
                        {formData.resumeFile ? 'Change resume' : 'Upload resume'}
                      </Button>
                      {formData.resumeFile && (
                        <span className="text-sm text-muted-foreground">
                          {formData.resumeFile.name}
                        </span>
                      )}
                    </div>
                    <input
                      id="resume"
                      name="resume"
                      type="file"
                      accept=".pdf,.doc,.docx"
                      onChange={handleFileChange}
                      className="hidden"
                      required
                    />
                    <p className="text-xs text-muted-foreground mt-2">
                      Accepted formats: PDF, DOC, DOCX
                    </p>
                  </div>
                  
                  <div className="flex justify-between pt-4">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setIsApplying(false)}
                      disabled={isSubmitting}
                    >
                      Cancel
                    </Button>
                    <Button
                      type="submit"
                      disabled={isSubmitting}
                      className="button-press"
                    >
                      {isSubmitting ? 'Submitting...' : 'Submit Application'}
                    </Button>
                  </div>
                </form>
              </div>
            ) : (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.4 }}
              >
                <div className="glass-card rounded-2xl p-8 mb-8">
                  <div className="flex flex-col md:flex-row gap-6">
                    {job.logo ? (
                      <div className="shrink-0 h-20 w-20 rounded-lg overflow-hidden bg-secondary">
                        <img 
                          src={job.logo} 
                          alt={`${job.company} logo`}
                          className="h-full w-full object-cover"
                        />
                      </div>
                    ) : (
                      <div className="shrink-0 h-20 w-20 rounded-lg overflow-hidden bg-primary/10 flex items-center justify-center">
                        <Briefcase className="h-8 w-8 text-primary/60" />
                      </div>
                    )}
                    
                    <div className="flex-1">
                      <h1 className="text-3xl font-display font-bold mb-2">
                        {job.title}
                      </h1>
                      <p className="text-xl text-muted-foreground mb-4">
                        {job.company} • {job.location}
                      </p>
                      
                      <div className="flex flex-wrap items-center gap-4 text-sm">
                        <div className="flex items-center text-foreground/70">
                          <Briefcase className="mr-1 h-4 w-4" /> 
                          <span>{job.type}</span>
                        </div>
                        <div className="flex items-center text-foreground/70">
                          <Calendar className="mr-1 h-4 w-4" /> 
                          <span>Posted {job.posted}</span>
                        </div>
                        {job.salary && (
                          <div className="font-medium text-foreground/80">
                            {job.salary}
                          </div>
                        )}
                      </div>
                    </div>
                    
                    <div className="md:self-start">
                      <Button 
                        size="lg" 
                        className="w-full md:w-auto button-press"
                        onClick={handleApply}
                      >
                        Apply Now
                      </Button>
                    </div>
                  </div>
                </div>
                
                <div className="glass-card rounded-2xl p-8">
                  <h2 className="text-xl font-semibold mb-4">Job Description</h2>
                  <div className="prose prose-neutral max-w-none text-foreground/80">
                    {job.description.split('\n\n').map((paragraph, index) => (
                      <React.Fragment key={index}>
                        {paragraph.includes(':') && paragraph.split('\n').map((line, i) => (
                          line.includes(':') ? (
                            <h3 key={i} className="font-semibold mt-6 mb-2">{line}</h3>
                          ) : (
                            <p key={i} className="mb-2">{line}</p>
                          )
                        ))}
                        {!paragraph.includes(':') && <p className="mb-4">{paragraph}</p>}
                      </React.Fragment>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}
          </div>
        </main>
      </AnimatedRoute>
    </>
  );
};

export default JobDetail;
