
import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { motion } from 'framer-motion';

const Navbar: React.FC = () => {
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();
  
  // Check if the user is logged in (in a real app this would check auth state)
  const isLoggedIn = localStorage.getItem('userLoggedIn') === 'true';

  // Handle scroll events to change navbar styling
  useEffect(() => {
    const handleScroll = () => {
      const offset = window.scrollY;
      if (offset > 10) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('userLoggedIn');
    localStorage.removeItem('userData');
    window.location.href = '/';
  };

  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ease-spring ${
        scrolled ? 'bg-white/80 backdrop-blur-lg shadow-sm' : 'bg-transparent'
      }`}
    >
      <div className="page-container">
        <div className="flex items-center justify-between h-20">
          <Link to="/" className="flex items-center space-x-2">
            <motion.div
              className="text-2xl font-display font-semibold bg-clip-text text-transparent bg-gradient-to-r from-primary to-primary/70"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              transition={{ duration: 0.3, ease: [0.25, 0.1, 0.25, 1] }}
            >
              JobTopia
            </motion.div>
          </Link>

          <nav className="hidden md:flex items-center space-x-1">
            <NavLink to="/" active={location.pathname === "/"}>Home</NavLink>
            <NavLink to="/jobs" active={location.pathname.startsWith("/jobs")}>Jobs</NavLink>
            {isLoggedIn && (
              <NavLink to="/profile" active={location.pathname === "/profile"}>Profile</NavLink>
            )}
          </nav>

          <div className="flex items-center space-x-3">
            {isLoggedIn ? (
              <>
                <Button size="sm" variant="outline" className="button-press" onClick={handleLogout}>
                  Log out
                </Button>
              </>
            ) : (
              <>
                <Button asChild size="sm" variant="outline" className="button-press">
                  <Link to="/auth?mode=login">Log in</Link>
                </Button>
                <Button asChild size="sm" className="button-press">
                  <Link to="/auth?mode=signup">Sign up</Link>
                </Button>
              </>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

// Helper component for navigation links
interface NavLinkProps {
  to: string;
  active: boolean;
  children: React.ReactNode;
}

const NavLink: React.FC<NavLinkProps> = ({ to, active, children }) => {
  return (
    <Link 
      to={to} 
      className={`relative px-3 py-2 text-sm font-medium transition-colors rounded-md hover:text-primary ${
        active ? 'text-primary' : 'text-foreground/80'
      }`}
    >
      {children}
      {active && (
        <motion.div 
          className="absolute -bottom-1 left-3 right-3 h-[2px] bg-primary rounded-full" 
          layoutId="navIndicator"
          transition={{ duration: 0.3, ease: [0.25, 0.1, 0.25, 1] }}
        />
      )}
    </Link>
  );
};

export default Navbar;
