
import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search } from 'lucide-react';
import { motion } from 'framer-motion';

interface SearchBarProps {
  onSearch: (query: string, location: string) => void;
}

const SearchBar: React.FC<SearchBarProps> = ({ onSearch }) => {
  const [query, setQuery] = useState('');
  const [location, setLocation] = useState('');
  const [isFocused, setIsFocused] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(query, location);
  };

  return (
    <motion.div 
      className={`relative w-full max-w-4xl mx-auto rounded-2xl glass-card p-1 transition-all duration-300 ${
        isFocused ? 'shadow-lg ring-2 ring-primary/20' : 'shadow-md'
      }`}
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, ease: [0.25, 0.1, 0.25, 1] }}
    >
      <form 
        onSubmit={handleSubmit}
        className="flex flex-col md:flex-row w-full gap-2 p-3"
      >
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            type="text"
            placeholder="Job title, keywords, or company..."
            className="pl-10 h-12 glass-input rounded-xl"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onFocus={() => setIsFocused(true)}
            onBlur={() => setIsFocused(false)}
          />
        </div>
        
        <div className="relative flex-1">
          <Input
            type="text"
            placeholder="Location (city, state, or remote)"
            className="h-12 glass-input rounded-xl"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            onFocus={() => setIsFocused(true)}
            onBlur={() => setIsFocused(false)}
          />
        </div>
        
        <Button type="submit" size="lg" className="h-12 px-6 bg-primary hover:bg-primary/90 rounded-xl transition-all button-press">
          Search Jobs
        </Button>
      </form>
    </motion.div>
  );
};

export default SearchBar;
