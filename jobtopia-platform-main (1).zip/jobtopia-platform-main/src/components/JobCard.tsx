
import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Badge } from '@/components/ui/badge';
import { Calendar, Briefcase } from 'lucide-react';

export interface JobData {
  id: string;
  title: string;
  company: string;
  location: string;
  salary?: string;
  type: string;
  posted: string;
  logo?: string;
  description: string;
}

interface JobCardProps {
  job: JobData;
  index: number;
}

const JobCard: React.FC<JobCardProps> = ({ job, index }) => {
  return (
    <motion.div
      className="group"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ 
        duration: 0.4,
        delay: index * 0.08,
        ease: [0.25, 0.1, 0.25, 1]
      }}
    >
      <Link to={`/jobs/${job.id}`} className="block">
        <div className="relative w-full p-6 glass-card rounded-2xl hover-scale">
          <div className="flex items-start gap-4">
            {job.logo ? (
              <div className="shrink-0 h-12 w-12 rounded-md overflow-hidden bg-secondary">
                <img 
                  src={job.logo} 
                  alt={`${job.company} logo`}
                  className="h-full w-full object-cover"
                />
              </div>
            ) : (
              <div className="shrink-0 h-12 w-12 rounded-md overflow-hidden bg-primary/10 flex items-center justify-center">
                <Briefcase className="h-6 w-6 text-primary/60" />
              </div>
            )}
            
            <div className="flex-1">
              <div className="flex flex-wrap items-start justify-between gap-2">
                <div>
                  <h3 className="font-semibold text-lg text-foreground leading-tight">
                    {job.title}
                  </h3>
                  <p className="text-muted-foreground mt-1">{job.company}</p>
                </div>
                {job.salary && (
                  <p className="font-medium text-sm text-foreground/80">
                    {job.salary}
                  </p>
                )}
              </div>
              
              <div className="mt-3 flex flex-wrap items-center gap-2">
                <Badge variant="secondary" className="font-normal text-xs">
                  {job.type}
                </Badge>
                <Badge variant="outline" className="font-normal text-xs">
                  {job.location}
                </Badge>
                <div className="flex items-center text-xs text-muted-foreground">
                  <Calendar className="mr-1 h-3 w-3" /> 
                  <span>{job.posted}</span>
                </div>
              </div>
              
              <p className="mt-3 text-sm text-muted-foreground line-clamp-2">
                {job.description}
              </p>
            </div>
          </div>
        </div>
      </Link>
    </motion.div>
  );
};

export default JobCard;
